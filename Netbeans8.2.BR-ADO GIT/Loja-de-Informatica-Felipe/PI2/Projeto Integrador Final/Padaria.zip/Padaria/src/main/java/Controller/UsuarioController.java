package Controller;

import Dao.UsuarioDAO;
import Model.Cargo;
import Model.Usuario;
import java.util.ArrayList;

public class UsuarioController {

    public static boolean salvar(String nome, String cpfCnpj, String cargo, String email, String senha, String dataNascimento) {
        Usuario user = new Usuario();
        user.setNome(nome);

        String formata = cpfCnpj.replace(".", "");
        String cpf = formata.replace("-", "");

        user.setCpfCnpj(cpf);
        
         ArrayList<Cargo> cargos = UsuarioController.selecionarListaCargos();

        for (Cargo cg : cargos) {
            if (cg.getCargo().equals(cargo)) {
                user.setIdCargo(cg.getId());
            }
        }
            
        user.setEmail(email);
        user.setNome(nome);
        user.setSenha(senha);
        user.setDataNascimento(dataNascimento);
        return UsuarioDAO.salvar(user);
    }

    public static boolean atualizar(int id, String nome, String cpfCnpj, int idCargo, String email, String dataNascimento) {
        Usuario user = new Usuario();
        user.setId(id);
        user.setNome(nome);

        String formata = cpfCnpj.replace(".", "");
        String cpf = formata.replace("-", "");

        user.setCpfCnpj(cpf);
        user.setIdCargo(idCargo);
        user.setEmail(email);
        user.setNome(nome);
        user.setDataNascimento(dataNascimento);
        return UsuarioDAO.atualizar(user);

    }

    public static boolean excluir(int id, int usr) {
        String iduser = String.valueOf(usr);
        return UsuarioDAO.excluir(id, iduser);
    }

    public static Usuario login(String email, String senha) {
        return UsuarioDAO.Login(email, senha);
    }

    public static Usuario selectId(String id) {
        return UsuarioDAO.selecionarId(Integer.parseInt(id));
    }

    public static ArrayList<Usuario> selectLista() {
        return UsuarioDAO.selecionarLista();
    }

    public static ArrayList<Cargo> selecionarListaCargos() {
        return UsuarioDAO.selecionarListaCargos();
    }
}
