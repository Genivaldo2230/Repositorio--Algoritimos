package Model;

public class Cliente {

    private int id;
    private String nome;
    private String cpfCnpj;
    private String email;
    private String telefone;
    private String sexo;
    private String estadoCivil;
    private String dataNascimento;
    private boolean excluido;
    private String dataExclusao;
    private String endereco;
    private int usrId;

    public Cliente() {

    }

    public Cliente(int _id, String _nome, String _cpfCnpj, String _email, String _telefone, String _sexo, String _estadoCivil, String _dataNascimento, boolean _excluido, String _dataExclusao, int _usrId,String _endereco) {
        this.id = _id;
        this.nome = _nome;
        this.cpfCnpj = _cpfCnpj;
        this.telefone = _telefone;
        this.sexo = _sexo;
        this.estadoCivil = _estadoCivil;
        this.dataNascimento = _dataNascimento;
        this.excluido = _excluido;
        this.dataExclusao = _dataExclusao;
        this.usrId = _usrId;
        this.endereco = _endereco;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpfCnpj() {
        return cpfCnpj;
    }

    public void setCpfCnpj(String cpfCnpj) {
        this.cpfCnpj = cpfCnpj;
    }

    public boolean isExcluido() {
        return excluido;
    }

    public void setExcluido(boolean excluido) {
        this.excluido = excluido;
    }

    public String getDataExclusao() {
        return dataExclusao;
    }

    public void setDataExclusao(String dataExclusao) {
        this.dataExclusao = dataExclusao;
    }

    public int getUsrId() {
        return usrId;
    }

    public void setUsrId(int usrId) {
        this.usrId = usrId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getEstadoCivil() {
        return estadoCivil;
    }

    public void setEstadoCivil(String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }

    public String getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

}
