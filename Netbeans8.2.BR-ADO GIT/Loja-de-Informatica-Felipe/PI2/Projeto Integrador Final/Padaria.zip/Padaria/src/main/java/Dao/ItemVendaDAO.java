/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Model.ItemVenda;
import Model.Venda;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ItemVendaDAO {

    public static boolean salvar(ItemVenda item) {
         boolean result = true;
         Connection con;
        try {
            con = DbConnection.obterConexao();
            String sql = "INSERT INTO tb_item_venda ( id_venda,id_produto,qtde,valor ) "
                    + "VALUES (?,?,?, (SELECT valor FROM tb_produto WHERE id_produto = ?))";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, item.getIdVenda());
            ps.setInt(2, item.getIdProduto());
            ps.setInt(3, item.getQtde());
            ps.setInt(4,item.getIdProduto());
           
            ps.execute();
            result = true;
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }

    public static boolean atualizar(ItemVenda item) {
        boolean result = true;
        return result;
    }

    public static boolean excluir(int id) {
        boolean result = true;
        return result;
    }

    public static ItemVenda selecionarId(int id) {
        ItemVenda item = new ItemVenda();
        return item;
    }

    public static ArrayList<ItemVenda> selecionarLista(int id) {
        ArrayList<ItemVenda> itens = new ArrayList<ItemVenda>();
        Connection con;
        try {
            con = DbConnection.obterConexao();
            String sqlState = "SELECT it.id_item,it.id_venda,it.id_produto,pd.nome, "
                    + "it.qtde , it.valor, (it.valor * it.qtde) AS total FROM "
                    + "tb_item_venda it INNER JOIN tb_produto pd ON pd.id_produto = it.id_produto "
                    + " WHERE it.id_venda = "+ id;

            PreparedStatement ps = con.prepareStatement(sqlState);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                ItemVenda item = new ItemVenda();
                item.setId(rs.getInt("id_item"));
                item.setIdProduto(rs.getInt("id_produto"));
                item.setProduto(rs.getString("nome"));
                item.setQtde(rs.getInt("qtde"));
                item.setValor(rs.getDouble("valor"));
                item.setValorTotal(rs.getDouble("total"));
                itens.add(item);
               
            }
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return itens;
    }

}
