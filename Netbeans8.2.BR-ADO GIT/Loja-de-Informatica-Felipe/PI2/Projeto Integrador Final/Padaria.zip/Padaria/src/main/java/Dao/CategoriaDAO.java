/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Model.Categoria;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Leonardo Moreno
 * @see controller.CategoriaController
 */
public class CategoriaDAO extends DbConnection {

    /**
     * Método para salvar uma categoria no banco
     *
     * @param categoria - objeto do tipo Categoria
     * @return boolean - true: sucesso , false:falha
     */
    public static boolean salvar(Categoria categoria) {
        boolean result = false;
        Connection con;
        try {
            con = DbConnection.obterConexao();
            String sql = "insert into tb_categoria (categoria)"
                    + " values (?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, categoria.getCategoria());
            ps.execute();
            result = true;
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return result;
    }

    /**
     * Método para atualizar uma categoria no banco
     *
     * @param categoria - objeto do tipo Categoria
     * @return boolean - true: sucesso , false:falha
     */
    public static boolean atualizar(Categoria categoria) {
        boolean result = false;

        Connection con;
        try {
            con = DbConnection.obterConexao();
            String sql = "update tb_categoria set categoria = ? where id_categoria = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, categoria.getCategoria());
            ps.setInt(2, categoria.getId());
            ps.execute();
            result = true;
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return result;
    }

    /**
     * Método para excluir uma categoria no banco
     *
     * @param p - objeto do tipo Cliente
     * @return boolean - true: sucesso , false:falha
     */
    public static boolean excluir(int id, String User) {
        boolean result = false;
        Connection con;
        Date date = new Date();
        String data = date.toInstant().toString().substring(0, 10);

        try {
            con = DbConnection.obterConexao();
            PreparedStatement ps = con.prepareStatement("update tb_categoria set excluido = true, data_exclusao = '" + data + "', usr_id = " + User + " where id_categoria = " + id);
            ps.executeUpdate();
            result = true;
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }

    /**
     * Método para selecionar uma categoria no banco
     *
     * @param id =  do tipo int
     * @return boolean - true: sucesso , false:falha
     */
    public static Categoria selecionarId(int id) {
        Categoria categoria = new Categoria();
        return categoria;
    }

    /**
     * Método para selecionar uma lista de categorias no banco
     *
     * @param null
     * @return ArrayList<Categoria> - true: sucesso , false:falha
     */
    public static ArrayList<Categoria> selecionarLista() {
        ArrayList<Categoria> categorias = new ArrayList<Categoria>();
        Connection con;
        try {
            con = DbConnection.obterConexao();
            String sqlState = "select * from tb_categoria where excluido is false";

            PreparedStatement ps = con.prepareStatement(sqlState);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Categoria categoria = new Categoria();
                categoria.setId(rs.getInt("id_categoria"));
                categoria.setCategoria(rs.getString("categoria"));
                categorias.add(categoria);
            }
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return categorias;
    }

}
