/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Model.Venda;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class VendaDAO {

    public static boolean salvar(Venda venda) {
        boolean result = true;
         Connection con;
        try {
            con = DbConnection.obterConexao();
            String sql = "INSERT INTO `tb_venda` (id_usr,valor_total,id_cliente) "
                    + "VALUES (?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, Integer.toString(venda.getIdUsr()));
            ps.setDouble(2, venda.getValorTotal());
            ps.setInt(3, venda.getIdCliente());
           
            ps.execute();
            result = true;
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }

    public static boolean atualizar(Venda venda) {
        boolean result = true;
        return result;
    }

    public static boolean excluir(int id) {
        boolean result = true;
        return result;
    }

    public static int selecionarIdvenda(int cliente) {
        int result = 0;
        Connection con;
        try {
            con = DbConnection.obterConexao();
            String sqlState = "SELECT id_venda FROM tb_venda where id_cliente = ? ORDER by data_venda DESC LIMIT 1;";
            PreparedStatement ps = con.prepareStatement(sqlState);
            ps.setInt(1, cliente);
            
            
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
               result = rs.getInt("id_venda");
            }
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        return result;
    }

    
    public static Venda selecionarId(int id) {
        Venda venda = new Venda();
        return venda;
    }

    public static ArrayList<Venda> selecionarLista() {
        ArrayList<Venda> vendas = new ArrayList<Venda>();
        return vendas;
    }

    public static ArrayList<Venda> RelatorioSintetico(Date inicio,Date fim) {
        ArrayList<Venda> vendas = new ArrayList<Venda>();
        Connection con;
        try {
            con = DbConnection.obterConexao();
            String sqlState = "SELECT vd.id_venda, vd.data_venda ,vd.valor_total ,"
                    + " cl.id_cliente ,cl.CPF ,cl.Nome FROM tb_venda vd inner join "
                    + "tb_cliente cl on vd.id_cliente = cl.id_cliente "
                    + "where vd.data_venda >= ? and vd.data_venda <= ?";

            PreparedStatement ps = con.prepareStatement(sqlState);
            ps.setDate(1, new java.sql.Date(inicio.getTime()));
            ps.setDate(2, new java.sql.Date(fim.getTime()));
            
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Venda venda = new Venda();
                venda.setId(rs.getInt("id_venda"));
                venda.setDataVenda(rs.getString("data_venda"));
                venda.setValorTotal(rs.getDouble("valor_total"));
                venda.setIdCliente(rs.getInt("id_cliente"));
                venda.setCpfCliente(rs.getString("cpf"));
                venda.setNomeCliente(rs.getString("nome"));
                vendas.add(venda);
               
            }
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return vendas;
    }

}
