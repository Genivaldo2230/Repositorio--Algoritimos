/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Dao.ProdutoDAO;
import Model.Categoria;
import Model.Produto;
import java.util.ArrayList;

public class ProdutoController {

    public static boolean salvar(String nome, int qtde, double valor,String categoria, String descricao, int user) {
        Produto produto = new Produto();
        String iduser = String.valueOf(user);
        produto.setNome(nome);
        produto.setQtde(qtde);
        produto.setValor(valor);
        
         ArrayList<Categoria> categorias = CategoriaController.selectLista();
        
        for (Categoria cat : categorias) {
            if (cat.getCategoria().equals(categoria)) {
                 produto.setIdCategoria(cat.getId());
            }
        }
        produto.setDescricao(descricao);
        produto.setUsrId(iduser);
        return ProdutoDAO.salvar(produto);
    }

    public static boolean atualizar(int id, double valor, int qtde,  String descricao) {
        Produto produto = new Produto();
        produto.setId(id);     
        produto.setValor(valor);     
        produto.setQtde(qtde);
        produto.setDescricao(descricao);
        return ProdutoDAO.atualizar(produto);

    }

    public static boolean excluir(int id, int user) {
        String iduser = String.valueOf(user);
        return ProdutoDAO.excluir(id, iduser);
    }

    public static Produto selectId(int id) {
        return ProdutoDAO.selecionarId(id);
    }
    
    public static ArrayList<Produto> selectNome(String nome) {
        return ProdutoDAO.selecionarNome(nome);
    }

    public static ArrayList<Produto> selectLista() {
        return ProdutoDAO.selecionarLista();
    }

}
