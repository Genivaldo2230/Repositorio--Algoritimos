/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Dao.ClienteDAO;
import Model.Cliente;
import java.util.ArrayList;

public class ClienteController {

    public static boolean salvar(String nome, String cpfCnpj, String telefone,
            String DataNascimento, String email, String sexo, String estado, String endereco,int user) {
        Cliente cliente = new Cliente();
        cliente.setUsrId(user);
        cliente.setNome(nome);

        String formata = cpfCnpj.replace(".", "");
        String cpf = formata.replace("-", "");

        cliente.setCpfCnpj(cpf);
        cliente.setEmail(email);
        cliente.setEstadoCivil(estado);
        cliente.setTelefone(telefone);
        cliente.setSexo(sexo);
        cliente.setDataNascimento(DataNascimento);
        cliente.setEndereco(endereco);
        return ClienteDAO.salvar(cliente);
    }

    public static boolean atualizar(String nome, String telefone,
            String DataNascimento, String email, String sexo, String estado, String endereco,int idcliente) {
        Cliente cliente = new Cliente();
        cliente.setId(idcliente);
        cliente.setNome(nome);
        cliente.setEmail(email);
        cliente.setEstadoCivil(estado);
        cliente.setTelefone(telefone);
        cliente.setSexo(sexo);
        cliente.setDataNascimento(DataNascimento);
        cliente.setEndereco(endereco);
        return ClienteDAO.atualizar(cliente);

    }

    public static boolean excluir(int id,int user) {
         String iduser = String.valueOf(user);
        return ClienteDAO.excluir(id, iduser);
    }

    public static Cliente selectId(int id) {
        return ClienteDAO.selecionarId(id);
    }
    
     public static Cliente selectCpf(String cpfBruto) {
        String formata = cpfBruto.replace(".", "");
        String cpf = formata.replace("-", "");
        return ClienteDAO.selecionarCpf(cpf);
    }

    public static ArrayList<Cliente> selectLista() {
        return ClienteDAO.selecionarLista();
    }

}
