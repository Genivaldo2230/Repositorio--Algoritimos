package Dao;

import Model.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ClienteDAO {

    public static boolean salvar(Cliente cliente) {
        boolean result = false;
        Connection con;
        try {
            con = DbConnection.obterConexao();
            String sql = "INSERT INTO tb_cliente (id_usr, CPF, Nome, telefone, data_nascimento, email, sexo, Estado_civil, endereco)"
                    + " values ( ? , ?,? , ? , ? , ? , ?, ?,?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, cliente.getUsrId());
            ps.setString(2, cliente.getCpfCnpj());
            ps.setString(3, cliente.getNome());
            ps.setString(4, cliente.getTelefone());
            ps.setString(5, cliente.getDataNascimento());
            ps.setString(6, cliente.getEmail());
            ps.setString(7, cliente.getSexo());
            ps.setString(8, cliente.getEstadoCivil());
            ps.setString(9, cliente.getEndereco());
            ps.execute();
            result = true;
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return result;
    }

    public static boolean atualizar(Cliente cliente) {
        boolean result = false;
        Connection con;
        try {
            con = DbConnection.obterConexao();
            String sql = "update tb_cliente set nome = ?,"
                    + "email = ?,"
                    + "endereco = ?,"
                    + "telefone = ?,"
                    + "sexo = ?,"
                    + "estado_civil = ?,"
                    + "data_nascimento = ?"
                    + " where id_cliente = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, cliente.getNome());
            ps.setString(2, cliente.getEmail());
            ps.setString(3, cliente.getEndereco());
            ps.setString(4, cliente.getTelefone());
            ps.setString(5, cliente.getSexo());
            ps.setString(6, cliente.getEstadoCivil());
            ps.setString(7, cliente.getDataNascimento());
            ps.setInt(8, cliente.getId());

            ps.executeUpdate();
            result = true;
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }

    public static boolean excluir(int id, String user) {
        boolean result = false;
        Connection con;
        Date date = new Date();
        String data = date.toInstant().toString().substring(0, 10);

        try {
            con = DbConnection.obterConexao();
            PreparedStatement ps = con.prepareStatement("update tb_cliente set excluido = true, data_exclusao = '" + data + "', usr_exclusao = " + user + " where id_cliente = " + id);
            ps.executeUpdate();
            result = true;
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return result;
    }

    public static Cliente selecionarId(int id) {
        Cliente cliente = new Cliente();
        Connection con;
        try {
            con = DbConnection.obterConexao();
            String sqlState = "select * from tb_cliente where id_cliente = " + id;

            PreparedStatement ps = con.prepareStatement(sqlState);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                cliente.setId(rs.getInt("id_cliente"));
                cliente.setCpfCnpj(rs.getString("cpf"));
                cliente.setNome(rs.getString("nome"));
                cliente.setEstadoCivil(rs.getString("estado_civil"));
                cliente.setSexo(rs.getString("sexo"));
                cliente.setTelefone(rs.getString("telefone"));
                cliente.setEmail(rs.getString("email"));
                cliente.setEndereco(rs.getString("endereco"));
                cliente.setDataNascimento(rs.getString("data_nascimento"));

            }
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cliente;
    }

    public static Cliente selecionarCpf(String cpf) {
        Cliente cliente = new Cliente();
        Connection con;
        try {
            con = DbConnection.obterConexao();
            PreparedStatement ps = con.prepareStatement("select * from tb_cliente where cpf like ?");
            ps.setString(1, '%' + cpf + '%');

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                cliente.setId(rs.getInt("id_cliente"));
                cliente.setNome(rs.getString("nome"));
            }
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cliente;
    }

    public static ArrayList<Cliente> selecionarLista() {
        ArrayList<Cliente> clientes = new ArrayList<Cliente>();
        Connection con;
        try {
            con = DbConnection.obterConexao();
            String sqlState = "select * from tb_cliente where excluido is false";

            PreparedStatement ps = con.prepareStatement(sqlState);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Cliente cliente = new Cliente();
                cliente.setId(rs.getInt("id_cliente"));
                cliente.setCpfCnpj(rs.getString("cpf"));
                cliente.setNome(rs.getString("nome"));
                clientes.add(cliente);
            }
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return clientes;
    }

}
