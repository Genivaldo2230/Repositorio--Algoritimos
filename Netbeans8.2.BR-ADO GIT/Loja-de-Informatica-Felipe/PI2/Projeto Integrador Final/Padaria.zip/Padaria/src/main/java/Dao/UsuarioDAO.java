/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Model.Cargo;
import Model.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UsuarioDAO {

    public static boolean salvar(Usuario usuario) {
        boolean result = false;
        Connection con;
        try {
            con = DbConnection.obterConexao();
            String sql = "INSERT INTO tb_usuario ( nome, cpf, data_nascimento, senha, email, id_cargo)"
                    + " values (? , ? , ? , ? , ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, usuario.getNome());
            ps.setString(2, usuario.getCpfCnpj());
            ps.setString(3, usuario.getDataNascimento());
            ps.setString(4, usuario.getSenha());
            ps.setString(5, usuario.getEmail());
            ps.setInt(6, usuario.getIdCargo());
            ps.execute();
            result = true;
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }

    public static boolean atualizar(Usuario usuario) {
        boolean result = true;
        Connection con;
        Date date = new Date();
        String data = date.toInstant().toString().substring(0, 10);

        try {
            con = DbConnection.obterConexao();
           String sql = "update tb_usuario set nome = ?,"
                   +"email = ?,"
                   +"cpf = ?,"
                   +"data_nascimento = ?"
                   +" where id_usr = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, usuario.getNome());
            ps.setString(2, usuario.getEmail());
            ps.setString(3, usuario.getCpfCnpj());
            ps.setString(4, usuario.getDataNascimento());
            ps.setInt(5, usuario.getId());
            ps.executeUpdate();
            result = true;
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }

    public static boolean excluir(int id, String user) {
        boolean result = true;
        Connection con;
        Date date = new Date();
        String data = date.toInstant().toString().substring(0, 10);

        try {
            con = DbConnection.obterConexao();
            PreparedStatement ps = con.prepareStatement("update tb_usuario set excluido = true, data_exclusao = '" + data + "', usr_id = " + user + " where id_usr = " + id);
            ps.executeUpdate();
            result = true;
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }

    public static Usuario selecionarId(int id) {
        Usuario usuario = new Usuario();
        Connection con;
        try {
            con = DbConnection.obterConexao();
            String sqlState = "SELECT * FROM tb_usuario us INNER JOIN tb_cargo cg  ON us.id_cargo = cg.id_cargo WHERE us.id_usr = " + id;

            PreparedStatement ps = con.prepareStatement(sqlState);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                usuario.setId(rs.getInt("id_usr"));
                usuario.setIdCargo(rs.getInt("id_cargo"));
                usuario.setCargo(rs.getString("cargo"));
                usuario.setCpfCnpj(rs.getString("cpf"));
                usuario.setNome(rs.getString("nome"));
                usuario.setDataNascimento(rs.getString("data_nascimento"));
                usuario.setEmail(rs.getString("email"));
            }
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return usuario;
    }
    
    public static Usuario Login(String email,String senha) {
        Usuario usuario = new Usuario();
        Connection con;
        try {
            con = DbConnection.obterConexao();
            String sqlState = "SELECT * FROM tb_usuario WHERE email = ? and senha = ? and excluido is false";

            PreparedStatement ps = con.prepareStatement(sqlState);
            ps.setString(1, email);
            ps.setString(2,senha);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                usuario.setId(rs.getInt("id_usr"));
                usuario.setIdCargo(rs.getInt("id_cargo"));
                usuario.setCpfCnpj(rs.getString("cpf"));
                usuario.setNome(rs.getString("nome"));
                usuario.setDataNascimento(rs.getString("data_nascimento"));
                usuario.setEmail(rs.getString("email"));
            }
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return usuario;
    }

    public static ArrayList<Usuario> selecionarLista() {
        ArrayList<Usuario> usuarios = new ArrayList<Usuario>();
        Connection con;
        try {
            con = DbConnection.obterConexao();
            String sqlState = "select * from tb_usuario where excluido is false";

            PreparedStatement ps = con.prepareStatement(sqlState);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Usuario usuario = new Usuario();
                usuario.setId(rs.getInt("id_usr"));
                usuario.setCpfCnpj(rs.getString("cpf"));
                usuario.setNome(rs.getString("nome"));
                usuarios.add(usuario);
            }
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return usuarios;
    }
    
     public static ArrayList<Cargo> selecionarListaCargos() {
        ArrayList<Cargo> cargos = new ArrayList<Cargo>();
        Connection con;
        try {
            con = DbConnection.obterConexao();
            String sqlState = "select * from tb_cargo";

            PreparedStatement ps = con.prepareStatement(sqlState);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Cargo cargo = new Cargo();
                cargo.setId(rs.getInt("id_cargo"));
                cargo.setCargo(rs.getString("cargo"));
                cargos.add(cargo);
            }
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cargos;
    }

}
