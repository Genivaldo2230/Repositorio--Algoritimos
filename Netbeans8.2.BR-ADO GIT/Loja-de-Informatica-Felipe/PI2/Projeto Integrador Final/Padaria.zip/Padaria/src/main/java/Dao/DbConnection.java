/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public abstract class DbConnection {

    public Statement st;
    public ResultSet rs;

    private static final String CAMINHO = "jdbc:mysql://localhost:3306/padaria"+"?useTimezone=true&serverTimezone=UTC&useSSL=false";
    private static final String USER = "root";
    private static final String SENHA = "";

    public static java.sql.Connection obterConexao()
            throws ClassNotFoundException, SQLException {
        // 1) Declarar o driver JDBC de acordo com o Banco de dados usado
        Class.forName("com.mysql.jdbc.Driver");
        // 2) Abrir a conexão
        java.sql.Connection conn = DriverManager.getConnection(CAMINHO, USER, SENHA);
        return conn;
    }

}
