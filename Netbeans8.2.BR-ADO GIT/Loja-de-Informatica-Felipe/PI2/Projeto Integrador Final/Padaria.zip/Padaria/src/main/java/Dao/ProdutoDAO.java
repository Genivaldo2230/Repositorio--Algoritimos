/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Model.Categoria;
import Model.Produto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ProdutoDAO {

    public static boolean salvar(Produto produto) {
        boolean result = false;
        Connection con;
        try {
            con = DbConnection.obterConexao();
            String sql = "INSERT INTO tb_produto (id_categoria, nome, qtde, descricao, valor, usr_id) "
                    + "VALUES (?, ?, ?, ?, ?,?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, produto.getIdCategoria());
            ps.setString(2, produto.getNome());
            ps.setInt(3, produto.getQtde());
            ps.setString(4, produto.getDescricao());
            ps.setDouble(5, produto.getValor());
            ps.setString(6, produto.getUsrId());
            ps.execute();
            result = true;
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return result;
    }

    public static boolean atualizar(Produto produto) {

        boolean result = false;
        Connection con;

        try {
            con = DbConnection.obterConexao();
            PreparedStatement ps = con.prepareStatement("UPDATE tb_produto SET valor = ?, qtde = ? ,descricao = ? WHERE id_produto = ?");
            ps.setDouble(1, produto.getValor());
            ps.setInt(2, produto.getQtde());
            ps.setString(3, produto.getDescricao());
            ps.setInt(4, produto.getId());
            
                    
            ps.executeUpdate();
            result = true;
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return result;
    }

    public static boolean atualizarQtde(int id, int qtde) {
        boolean result = false;
        Connection con;

        try {
            con = DbConnection.obterConexao();
            PreparedStatement ps = con.prepareStatement("update tb_produto set qtde = (SELECT qtde-" + qtde + " FROM tb_produto where id_produto =" + id + ") where id_produto =" + id);
            ps.executeUpdate();
            result = true;
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }

    public static boolean excluir(int id, String user) {
        boolean result = false;
        Connection con;
        Date date = new Date();
        String data = date.toInstant().toString().substring(0, 10);

        try {
            con = DbConnection.obterConexao();
            PreparedStatement ps = con.prepareStatement("update tb_produto set excluido = true, data_exclusao = '" + data + "', usr_exclusao = " + user + " where id_produto = " + id);
            ps.executeUpdate();
            result = true;
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }

    public static Produto selecionarId(int id) {
        Produto produto = new Produto();
        Connection con;
        try {
            con = DbConnection.obterConexao();
            PreparedStatement ps = con.prepareStatement("SELECT prod.id_produto,prod.nome,prod.descricao,prod.qtde,prod.valor,cat.id_categoria ,cat.categoria FROM tb_produto prod INNER JOIN tb_categoria cat WHERE prod.id_categoria = cat.id_categoria and prod.excluido is false and id_produto =" + id);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                produto.setId(rs.getInt("id_produto"));
                produto.setIdCategoria(rs.getInt("id_categoria"));
                produto.setCategoria(rs.getString("categoria"));
                produto.setNome(rs.getString("nome"));
                produto.setDescricao(rs.getString("descricao"));
                produto.setQtde(rs.getInt("qtde"));
                produto.setValor(rs.getDouble("valor"));
            }
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return produto;
    }

    public static ArrayList<Produto> selecionarNome(String nome) {
        ArrayList<Produto> produtos = new ArrayList<Produto>();

        Connection con;
        try {
            con = DbConnection.obterConexao();
            PreparedStatement ps = con.prepareStatement("SELECT prod.id_produto,prod.nome,prod.descricao,prod.qtde,prod.valor,cat.id_categoria ,cat.categoria FROM tb_produto prod INNER JOIN tb_categoria cat WHERE prod.id_categoria = cat.id_categoria and prod.excluido is false and prod.nome like ?");
            ps.setString(1, nome + '%');

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Produto produto = new Produto();
                produto.setId(rs.getInt("id_produto"));
                produto.setIdCategoria(rs.getInt("id_categoria"));
                produto.setCategoria(rs.getString("categoria"));
                produto.setNome(rs.getString("nome"));
                produto.setDescricao(rs.getString("descricao"));
                produto.setQtde(rs.getInt("qtde"));
                produto.setValor(rs.getDouble("valor"));
                produtos.add(produto);
            }
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return produtos;
    }

    public static ArrayList<Produto> selecionarLista() {
        ArrayList<Produto> produtos = new ArrayList<Produto>();

        Connection con;
        try {
            con = DbConnection.obterConexao();
            String sqlState = "SELECT prod.id_produto,prod.nome,prod.descricao,prod.qtde,prod.valor,cat.id_categoria ,cat.categoria FROM tb_produto prod INNER JOIN tb_categoria cat WHERE prod.id_categoria = cat.id_categoria and prod.excluido is false";

            PreparedStatement ps = con.prepareStatement(sqlState);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Produto produto = new Produto();
                produto.setId(rs.getInt("id_produto"));
                produto.setIdCategoria(rs.getInt("id_categoria"));
                produto.setCategoria(rs.getString("categoria"));
                produto.setNome(rs.getString("nome"));
                produto.setDescricao(rs.getString("descricao"));
                produto.setQtde(rs.getInt("qtde"));
                produto.setValor(rs.getDouble("valor"));
                produtos.add(produto);
            }
            ps.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CategoriaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return produtos;
    }

}
