/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Dao.ItemVendaDAO;
import Dao.ProdutoDAO;
import Dao.VendaDAO;
import Model.ItemVenda;
import Model.Venda;
import java.util.ArrayList;
import java.util.Date;

public class VendaController {

    public static boolean registraVenda(int usuario, int cliente, double total, ArrayList<ItemVenda> itens) {
        boolean result = false;

        try {
            Venda venda = new Venda();
            venda.setIdUsr(usuario);
            venda.setIdCliente(cliente);
            venda.setValorTotal(total);

            if (VendaDAO.salvar(venda)) {
                int idVenda = VendaDAO.selecionarIdvenda(cliente);

                for (ItemVenda item : itens) {
                    item.setIdVenda(idVenda);
                    if (ItemVendaDAO.salvar(item)) {
                        ProdutoDAO.atualizarQtde(item.getIdProduto(), item.getQtde());
                    }
                }

                result = true;
                return result;
            }

        } catch (Exception ex) {
        }

        return result;
    }

    public static ArrayList<Venda> RelatorioSintetico(Date inicio, Date fim) {
        return VendaDAO.RelatorioSintetico(inicio, fim);
    }

}
